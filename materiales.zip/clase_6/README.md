

- [Ejemplo 1](ejemplo_1/app.R)
- [Ejemplo 2.a](ejemplo_2_a/app.R)
- [Ejemplo 2.b](ejemplo_2_b/app.R)
- [Ejemplo 2.c](ejemplo_2_c/app.R)
- [Ejemplo 2.d](ejemplo_2_d/app.R)